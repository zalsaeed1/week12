<?php

       if(isset($_POST['submit'])) // if submit parameter exist
   {
       // collect all data from HTML form

           $name = $_POST["name"];
           $address = $_POST["address"];
           $city_state_zip = $_POST["city_state_zip"];

           $light1 = $_POST["light1"];
           $light2 = $_POST["light2"];
           $long_lie = $_POST["long_lie"];
           $long_life = $_POST["long_life"];

           // create four variables and initializing the value

           $light1_price = 2.39;
           $light2_price = 4.29;
           $long_lie_price = 3.95;
           $long_life_price = 7.49;

           // calculate the total of the ordered light bulbs

           $total = ($light1_price*$light1)+($light2_price*$light2)+($long_lie_price*$long_lie)+($long_life_price*$long_life);

           // calculate the total cost of the ordered light bulbs after adding 6% sales tax

           $total_cost = $total+$total*0.06;
   }

?>

<!DOCTYPE html>
<!-- 9.10exercise.html 
        Zahraa Al Saeed
        ACSG-540-01
        11/14/2021
        -->

<html lang="en">
<head>
  <meta charset="uft-8">
  <title> 9.10 exercise </title>
</head>
<body>       <!-- open body tag -->

   <!-- create Heading -->

   <h1>Welcome Light of your Life</h1>
   <h1>Light Bulbs Sales</h1>

   <!-- create table -->

   <table border="1">       <!-- open table tag -->
       <tr>
           <td>Buyer’s name:</td>
           <td><?php echo $name; ?></td>   <!-- display Buyer’s name -->
       </tr>
       <tr>
           <td>Street Address:</td>
           <td><?php echo $address; ?></td>   <!-- display Street Address -->
       </tr>
       <tr>
           <td>City, State, Zip code:</td>
           <td><?php echo $city_state_zip; ?></td>       <!-- display City, State, Zip code -->
       </tr>
   </table>       <!-- close table tag -->

   <br><br>

   <!-- create table -->

   <table border="1">       <!-- open table tag -->
       <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
       </tr>
       <tr>
           <td>100-watt light bulbs</td>
           <td>$2.39</td>
           <td><?php echo $light1; ?></td>       <!-- display Quantity -->
       </tr>
       <tr>
           <td>100-watt light bulbs</td>
           <td>$4.29</td>
           <td><?php echo $light2; ?></td>       <!-- display Quantity -->
       </tr>
       <tr>
           <td>100-watt long-lie light bulbs</td>
           <td>$3.95</td>
           <td><?php echo $long_lie; ?></td>       <!-- display Quantity -->
       </tr>
       <tr>
           <td>100-watt long-life light bulbs</td>
           <td>$7.49</td>
           <td><?php echo $long_life; ?></td>       <!-- display Quantity -->
       </tr>
       <tr>
           <th>Total Cost</th>
           <th colspan="2">$<?php echo $total_cost; ?></th>   <!-- display Total Cost -->
       </tr>
   </table>       <!-- close table tag -->
  
</body>       <!-- close body tag -->
</html>       <!-- close html tag -->